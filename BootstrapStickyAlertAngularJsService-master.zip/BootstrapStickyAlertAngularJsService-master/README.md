# Bootstrap Sticky Alert AngularJs Service
Bootstrap 3.0 Sticky Alerts using Angular JS service

Let's face it, your users need sweet little notifications to keep them all warm and fuzzy inside. Below angualrJs code snippet allows you to send such messages with ease, and class. Quickly notify a user of software updates, process completions, or annoy them with registration reminders. This AngularJS directive which handles notifications that makes it easy to create alert - success - error - warning - information - confirmation messages as an alternative the standard alert dialogue. Each notification is added to a queue. (Optional). The notifications can be positioned anywhere with ease through CSS

1. Same type of notifications is only active on screen once in case if multiple clicks.
2. Close button result in removal of notification from queue.
3. Timeout value can be increased or decreased as per need. 
