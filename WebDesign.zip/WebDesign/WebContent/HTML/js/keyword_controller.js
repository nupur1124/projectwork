var app = angular.module('myApp', ['zingchart-angularjs' ]);
app.controller('KeywordListCtrl',function($scope, $http, $templateCache) {
		$scope.listKeywords = function(keyword) {
 			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/predictKeywords/'+keyword, cache: $templateCache}).
  				success(function(data, status, headers, config) {
  					
  					
    		    	$scope.apps = data.results;                  //set view model
    		    	$scope.view = './Partials/keywords.html'; //set to list view
  				}).
  				error(function(data, status, headers, config) {
  					$scope.apps = data || "Request failed";
  					$scope.status = status;
  					$scope.view = './Partials/keywords.html';
  				});
  		}
		
 
  		$scope.PredictLoc= function(mySelect) {
  	
 			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/locationprediction/'+mySelect, cache: $templateCache}).
  				success(function(data, status, headers, config) {
  					
  					
    		    	$scope.list = data;                  //set view model
    		    	$scope.view = './Partials/location.html'; //set to list view
  				}).
  				error(function(data, status, headers, config) {
  					$scope.list = data || "Request failed";
  					$scope.status = status;
  					$scope.view = './Partials/location.html';
  				});
  		}
  		/*$scope.view = './Partials/list.html'; //set default view
  		$scope.listApps();*/
 	})
 	