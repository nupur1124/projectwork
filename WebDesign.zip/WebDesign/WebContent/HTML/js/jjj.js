
var app = angular.module('myApp', ['zingchart-angularjs' ]);

app.service("sampleService", function () {
	this.user = { name: 'Suresh Dasari', Location: 'Chennai' }
	this.designation='Team Leader'
	})	
app.controller('controller', function ($scope, $http,$templateCache) {
	    		
    			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/graphs/pie', cache: $templateCache}).
  				success(function(data, status, headers, config) {
  					$scope.list=data;
  					$scope.view1 = './index.html'
  					$scope.xAxis=[];
  					$scope.yAxis=[];
  				//	$scope.calling=AppListCtrl;
  					var i=0;
  					for( i=0;i<data.length;i++){
  						$scope.xAxis.push(data[i].Year);
  						$scope.yAxis.push(data[i].QuarterRet);
  						
  				  					}
  					 $scope.$on('parentmethod', function (event, args) {
  						
  			            $scope.Message = args.data;
  			        });
  					$scope.myData=[$scope.xAxis,$scope.yAxis];
  					
    		    	$scope.myJson = {                 //set view model
    		    	 //set to list view
    		    	 type : 'line',
    		    	
    		    	  "scale-x":{
    		    	    "values":$scope.xAxis,
    		    	    "format":"year %v"
    		    	  },
    		    	  "scale-y":{
    		    	    "values":"$scope.yAxis:50:5",
    		    	    "format":"%v",
    		    	    "guide":{
    		    	      "line-style":"dashdot"
    		    	    }
    		    	  },
    		    	  "plot":{
    		    		  "aspect":"spline",
    		    	    "contour-on-top":false,
    		    	    "marker":{
    		    	      "visible":false
    		    	    }
    		    	  },
  					 series : [
    							{ values :$scope.yAxis}
								    
  							  ]
    		    	};	
    		   	});

	
});

app.controller('AppListCtrl',function($scope, $http, $templateCache) {
	
	$scope.listApps = function(year,quater) {
			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/prediction/'+year+'/'+quater, cache: $templateCache}).
				success(function(data1, status, headers, config) {
					
					
		    	$scope.apps = data1;                  //set view model
		    	$scope.view = './NewFile1.html'; //set to list view
		    	 $scope.$broadcast('parentmethod', { data: "hello" });
		      	
				}).
				error(function(data, status, headers, config) {
					$scope.apps = data || "Request failed";
					$scope.status = status;
					$scope.view = './NewFile1.html';
				});
		}
})

app.controller('FundsCtrl',function($scope, $http, $templateCache) {
	$scope.FundsController = function(year) {
			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/comparison/'+year, cache: $templateCache}).
				success(function(data, status, headers, config) {
					
					
		    	$scope.files = data;                  //set view model
		    	$scope.views = './Partials/NewFile3.html'; //set to list view
				}).
				error(function(data, status, headers, config) {
					$scope.files = data || "Request failed";
					$scope.status = status;
					$scope.views = './Partials/NewFile3.html';
				});
		}
})


	

app.controller('KeywordListCtrl',function($scope, $http, $templateCache) {
		$scope.listKeywords = function(keyword) {
 			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/predictKeywords/'+keyword, cache: $templateCache}).
  				success(function(data, status, headers, config) {
  					
  					
    		    	$scope.apps = data.results;                  //set view model
    		    	$scope.view = './Partials/keywords.html'; //set to list view
  				}).
  				error(function(data, status, headers, config) {
  					$scope.apps = data || "Request failed";
  					$scope.status = status;
  					$scope.view = './Partials/keywords.html';
  				});
  		}
		
 
 
  		
 	})
 	
