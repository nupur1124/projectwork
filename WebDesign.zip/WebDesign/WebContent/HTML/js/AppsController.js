
var app = angular.module('myApp', ['zingchart-angularjs' ]);

app.service("sampleService", function(){
	               //set view model
	    	
	      this.apps1='999'
	      this.apps2='000'
		
});
	
	
	
app.controller('controller', function ($scope, $http,$templateCache,sampleService) {
	    		
    			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/graphs/pie', cache: $templateCache}).
  				success(function(data, status, headers, config) {
  					$scope.list=data;
  					$scope.view1 = './index.html'
  					$scope.xAxis=[];
  					$scope.yAxis=[];
  					
  			
  				
  		
  					var i=0;
  					for( i=0;i<data.length;i++){
  						$scope.xAxis.push(data[i].Year);
  						$scope.yAxis.push(data[i].QuarterRet);
  						
  				  					}
  					$scope.xAxis.push(sampleService.apps1);
  					$scope.yAxis.push(sampleService.apps2);
  					$scope.myData=[$scope.xAxis,$scope.yAxis];
  					
    		    	$scope.myJson = {                 //set view model
    		    	 //set to list view
    		    	 type : 'line',
    		    	
    		    	  "scale-x":{
    		    	    "values":$scope.xAxis,
    		    	    "format":"year %v"
    		    	  },
    		    	  "scale-y":{
    		    	    "values":"$scope.yAxis:50:5",
    		    	    "format":"%v",
    		    	    "guide":{
    		    	      "line-style":"dashdot"
    		    	    }
    		    	  },
    		    	  "plot":{
    		    		  "aspect":"spline",
    		    	    "contour-on-top":false,
    		    	    "marker":{
    		    	      "visible":false
    		    	    }
    		    	  },
  					 series : [
    							{ values :$scope.yAxis}
								    
  							  ]
    		    	};	
    		   	});

	
});

app.controller('AppListCtrl',function($scope, $http, $templateCache,sampleService) {
	
	$scope.listApps = function(year,quater) {
			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/prediction/'+year+'/'+quater, cache: $templateCache}).
				success(function(data1, status, headers, config) {
					
					
		    	$scope.apps =   data1; 
		    	sampleService.apps1=$scope.apps.year;
		    	sampleService.apps2=$scope.apps.quarterReturn;
		    	//set view model
		    	$scope.view = './NewFile1.html'; //set to list view
		    	 $scope.$broadcast('parentmethod', { data: "hello" });
		      	
				}).
				error(function(data, status, headers, config) {
					$scope.apps = data || "Request failed";
					$scope.status = status;
					$scope.view = './NewFile1.html';
				});
		}
})

app.controller('FundsCtrl',function($scope, $http, $templateCache) {
	$scope.FundsController = function(year) {
			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/comparison/'+year, cache: $templateCache}).
				success(function(data, status, headers, config) {
					
				$scope.year=year;
		    	$scope.files = [];                  //set view model
		    	for(var i=0;i<data.length-2;){
		    		$scope.files.push({name:data[i].shareName,first:data[i].quarterReturn,second:data[i+1].quarterReturn,third:data[i+2].quarterReturn})
		    		i=i+3;
		    	}
		    	console.log($scope.files);
		    	$scope.views = './Partials/NewFile3.html'; //set to list view
				}).
				error(function(data, status, headers, config) {
					$scope.files = data || "Request failed";
					$scope.status = status;
					$scope.views = './Partials/NewFile3.html';
				});
		}
})


	

app.controller('KeywordListCtrl',function($scope, $http, $templateCache) {
		$scope.listKeywords = function(keyword) {
 			$http({method: 'GET', url: 'http://pc326092.cts.com:8085/KIID_DataAnalysis/predictKeywords/'+keyword, cache: $templateCache}).
  				success(function(data, status, headers, config) {
  					
  					
    		    	$scope.apps = data.results;                  //set view model
    		    	$scope.view = './Partials/keywords.html'; //set to list view
  				}).
  				error(function(data, status, headers, config) {
  					$scope.apps = data || "Request failed";
  					$scope.status = status;
  					$scope.view = './Partials/keywords.html';
  				});
  		}
		
 
 
  		
 	})
 	
 	
app.filter('unique', function() {
   // we will return a function which will take in a collection
   // and a keyname
   return function(collection, keyname) {
      // we define our output and keys array;
      var output = [], 
          keys = [];

      // we utilize angular's foreach function
      // this takes in our original collection and an iterator function
      angular.forEach(collection, function(item) {
          // we check to see whether our object exists
          var key = item[keyname];
          // if it's not already part of our keys array
          if(keys.indexOf(key) === -1) {
              // add it to our keys array
              keys.push(key); 
              // push this item to our final output array
              output.push(item);
          }
      });
      // return our array which should be devoid of
      // any duplicates
      return output;
   };
});
 	
